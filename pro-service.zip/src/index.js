require('../scss/main.scss');
export * from '../js/main';

